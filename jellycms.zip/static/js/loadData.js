function loadData(jsonStr, form){
	var obj = jsonStr;
	var key,value,tagName,type,arr;
	$(form + "[name='"+key+"'],[name='"+key+"[]']").attr('checked',false);
	for(x in obj){
		key = x;
		value = obj[x];
		$(form+ " [name='"+key+"'],"+form+" [name='"+key+"[]']").each(function(){
			tagName = $(this)[0].tagName;
			type = $(this).attr('type');
			if(tagName=='INPUT'){
				if(type=='radio'){
					$(this).attr('checked',$(this).val()==value);
				}else if(type=='checkbox'){
					arr = JSON.parse(JSON.stringify(value));
					if(typeof(arr) == 'string' || typeof(arr) == 'number'){//单个值处理
						if($(this).val()== parseInt(arr)){
							$(this).attr('checked',true);
						}
					}else{ //多个值
						if(arr == null)arr='';//值为null时会报错
						for(var i =0;i<arr.length;i++){
							if($(this).val()==arr[i]){
								$(this).attr('checked',true);
								break;
							}
						}
					}
				}else{
					$(this).val(value);
				}
			}else if(tagName=='SELECT' || tagName=='TEXTAREA'){
				$(this).val(value);
			}
		});
	}
}	